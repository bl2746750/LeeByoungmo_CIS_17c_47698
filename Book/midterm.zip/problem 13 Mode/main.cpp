/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on October 1st, 2019, 7:45 PM
 */

//Libraries
#include <cstdlib>//Random number seed
#include <ctime>//Set the seed
#include <iostream>//I/O
#include <set>
#include <map>
#include <bits/stl_set.h>
#include <bits/stl_map.h>
using namespace std;

//No Global Constants

//Function Prototypes
int *fillAry(int,int);
void prntAry(int *,int,int);
void prntMod(int*);
void swap(int *,int *);
void minPos(int *,int,int);
void mrkSort(int *,int);
int* mode(const int *,int);
int *copy(const int *,int);

//Execution begins here
int main(int argc, char*argv[]) {
    srand(static_cast<unsigned int>(time(0)));
    //Declare variables and fill
    int arySize=50;
    int modNum=12;
    int *ary=fillAry(arySize,modNum);
    
    //Print the initial array
    prntAry(ary,arySize,10);
    
    //Calculate the mode array
    int* modeAry=mode(ary,arySize);
    
    //Print the modal information of the array
    prntMod(modeAry);
    
    //Delete allocated memory
    delete []ary;
//    delete []modeAry;
    
    //Exit stage right
    return 0;
}

int *copy(const int *a,int n){
    //Declare and allocate an array
    //that is a c
    int *b=new int[n];
    //Fill
    for(int i=0;i<n;i++){
        b[i]=a[i];
    }
    //Return the copy
    return b;
}

int* mode(const int *array,int arySize){
    set<int> arySet1(array,array+arySize);
    multiset<int> arySet(array,array+arySize);
    int* ary;
    int seqCheck=0;
    int seqNum=-1;
    int maxFreq=0;
    int cnt=0;
    
    
    set<int>::iterator iter=arySet1.begin();
    while(seqCheck>=0&&iter!=arySet1.end()){
        if(*iter==seqCheck){
            seqCheck++;
            seqNum=*iter;
            iter++;
        }
        else seqCheck=-1;
    }
    ary=new int [seqNum+2];

    
    map<int,int> aryMap;
    for(auto elem:arySet){
        ++aryMap[elem];
    }
    cout << endl;
    map<int,int>::iterator pos;
      
    for(pos=aryMap.begin();pos!=aryMap.end();++pos){
        if(maxFreq<pos->second) maxFreq=pos->second;
//        cout << pos->first << " " << pos->second << endl;
    }
    
    ary[1]=maxFreq;
    
    //Find the number of modes
    if(seqNum<0||arySet.count(0)!=maxFreq) {
        ary[0]=0;
        maxFreq=0;
    }
    else {
        pos=aryMap.begin();
        while(pos->second==maxFreq&&pos!=aryMap.end()){
            ary[cnt+2]=pos->first;
            if(pos->second==maxFreq) ary[0]=pos->first+1;
            ++pos;
            ++cnt;
        }
    }
    
    cout<<"Mode Freq = "<<maxFreq<<endl;
    cout<<"Number of modes = "<<ary[0]<<endl;
    return ary;
}

void prntMod(int* ary){
    cout<<endl;
    cout<<"The number of modes = "<<
            ary[0]<<endl;
    cout<<"The max Frequency = "<<
            ary[1]<<endl;
    if(ary[0]==0){
        cout<<"The mode set = {null}"<<endl;
        return;
    }
    cout<<"The mode set = {";
    for(int i=2;i<ary[0]+1;i++){
        cout<<ary[i]<<",";
    }
    cout<<ary[ary[0]+1]<<"}"<<endl;
}

void mrkSort(int *array,int n){
    for(int i=0;i<n-1;i++){
        minPos(array,n,i);
    }
}

void minPos(int *array,int n,int pos){
    for(int i=pos+1;i<n;i++){
        if(*(array+pos)>*(array+i))
            swap(array+pos,array+i);
    }
}

void swap(int *a,int *b){
    //Swap in place
    *a=*a^*b;
    *b=*a^*b;
    *a=*a^*b;
}

void prntAry(int *array,int n,int perLine){
    //Output the array
    cout<<endl;
    for(int i=0;i<n;i++){
        cout<<*(array+i)<<" ";
        if(i%perLine==(perLine-1))cout<<endl;
    }
    cout<<endl;
}

int *fillAry(int n, int modNum){
    //Allocate memory
    int *array=new int[n];
    
    //Fill the array with 2 digit numbers
    for(int i=0;i<n;i++){
        *(array+i)=i%modNum;
        //*(array+i)=rand()%modNum;
    }
    
    //Exit function
    return array;
}