/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   customer.h
 * Author: libmo
 *
 * Created on December 7, 2019, 3:15 AM
 */

#ifndef CUSTOMER_H
#define CUSTOMER_H

struct customer{
        float arrTime;
        float waitTime;
        float servTime;
        float totalTime;
    };


#ifdef __cplusplus
extern "C" {
#endif




#ifdef __cplusplus
}
#endif

#endif /* CUSTOMER_H */

